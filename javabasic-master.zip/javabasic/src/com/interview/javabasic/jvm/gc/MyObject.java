package com.interview.javabasic.jvm.gc;

public class MyObject {
    public MyObject childNode;
}
