package com.interview.javabasic.jvm.model;

public class ByteCodeSample {
    public static int add(int a, int b) {
        int c = 0;
        c = a + b;
        return c;
    }
}
