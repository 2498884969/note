package com.interview.javabasic.thread;

public class CurrentThreadDemo {
    public static void main(String[] args) {
        System.out.println("Current Thread: " + Thread.currentThread().getName());
    }
}
